// script.js

// Select DOM elements
const taskInput = document.getElementById('taskInput');
const addTaskBtn = document.getElementById('addTaskBtn');
const taskList = document.getElementById('taskList');

// Event listener for adding tasks
addTaskBtn.addEventListener('click', function () {
  const taskText = taskInput.value.trim();
  if (taskText !== '') {
    // Create a new list item
    const li = document.createElement('li');
    li.className = 'task-item';

    // Create a span for the task text
    const taskSpan = document.createElement('span');
    taskSpan.textContent = taskText;

    // Create a check icon for marking as completed
    const checkIcon = document.createElement('i');
    checkIcon.classList.add('fas', 'fa-check-circle');
    checkIcon.addEventListener('click', function () {
      li.classList.toggle('completed');
    });

    // Create a trash icon for deleting the task
    const deleteIcon = document.createElement('i');
    deleteIcon.classList.add('fas', 'fa-trash-alt');
    deleteIcon.addEventListener('click', function () {
      li.remove(); // Remove the task from the list
    });

    // Append span and icons to the list item
    li.appendChild(taskSpan);
    li.appendChild(checkIcon);
    li.appendChild(deleteIcon);

    // Append the list item to the task list
    taskList.appendChild(li);

    // Clear the input field
    taskInput.value = '';
  } else {
    alert('Please enter a task.');
  }
});

// Optional: Allow pressing Enter to add a task
taskInput.addEventListener('keypress', function (event) {
  if (event.key === 'Enter') {
    addTaskBtn.click();
  }
});